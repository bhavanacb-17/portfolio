
Portfolio for Bhavana Chenna

Files:
- index.html : single-page portfolio

How to use:
1. Open index.html in a browser to preview locally.
2. To publish:
   - Option A (GitHub Pages): create a repo, push these files to the repo root or 'gh-pages' branch and enable Pages.
   - Option B (Netlify/Vercel): drag & drop the folder or connect the GitHub repo for automatic deploys.

Edit content:
- Open index.html in a text editor and update text, links, or add screenshots inside the Projects section.

Generated on: 2025-09-22
